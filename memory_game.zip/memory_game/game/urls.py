# backend/game/urls.py
from django.urls import path
from .views import ScoreListCreateView, UserScoresListView,TopScoresListView

urlpatterns = [
    path('submit-score/', ScoreListCreateView.as_view(), name='submit-score'),
    path('user-scores/', TopScoresListView.as_view(), name='global-scores'),
    path('my-scores/', UserScoresListView.as_view(), name='user-scores'),
]
    